# IBEC website

Site for the **Intercollegiate Bike Engineering Competition**. Plain HTML/CSS/JS, no build step. Fonts: Barlow Condensed (headings) and Inter (body), self-hosted.
Open `index.html` in a browser to preview.

## Editing content
Almost everything lives in `assets/js/data.js`:

- `IBEC.site`: contact email, event details, social links
- `IBEC.schools`: school cards (team photo, university logo, team link)
- `IBEC.sponsors`: sponsors/partners
- `IBEC.faq`: About page FAQ
- `IBEC.gallery`: About page photo gallery

Text that starts with `TODO:` is shown highlighted on the page so it's easy to find.

## Logo
The header/footer use a placeholder mountain badge. To use the real logo, save it as
`assets/img/logo.png` and set `LOGO_SRC = "assets/img/logo.png"` near the top of `assets/js/site.js`.
Replace `assets/img/favicon.svg` too.

## Forms
The Register and Contact forms open the visitor's email app addressed to `IBEC.site.email`.

## Hosting (GitHub Pages)
1. Push to `main`.
2. Repo Settings → Pages → Deploy from a branch → `main` / `(root)`.
3. Once the domain is bought, add it under Settings → Pages → Custom domain
   (GitHub creates a `CNAME` file) and point the domain's DNS at GitHub Pages.

## Photos
Photos are from Sea Otter 2023–2026. University logos come from Wikimedia Commons.
