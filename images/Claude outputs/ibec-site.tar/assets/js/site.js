/* =========================================================================
   IBEC site script
   - Injects the shared header and footer into every page
   - Renders content from data.js into elements with [data-render]
   - Contact / registration forms open an email (until a form service is set up)
   ========================================================================= */
(function () {
  "use strict";
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
  const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  // Text starting with "TODO:" is highlighted so it's easy to find and replace
  const txt = (s) => (/^TODO:/.test(String(s || "")) ? `<mark class="todo">${esc(s)}</mark>` : esc(s));
  const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const S = IBEC.site;
  document.documentElement.classList.remove("no-js");

  /* ---------- Placeholder logo (swap for the real one later) ---------- */
  // To use a real logo: put it at assets/img/logo.png and set LOGO_SRC below.
  const LOGO_SRC = "";
  const LOGO_SVG = `
    <svg class="logo-mark" viewBox="0 0 64 64" aria-hidden="true">
      <circle cx="32" cy="32" r="30" fill="currentColor"/>
      <circle cx="32" cy="32" r="26.5" fill="none" stroke="var(--pearl)" stroke-width="1.5" opacity=".55"/>
      <path d="M8 44 L22 26 L29 35 L38 20 L56 44 Z" fill="var(--pearl)"/>
      <path d="M38 20 L33 28 L36 27 L39 31 L41 27 L44 28 Z" fill="currentColor" opacity=".35"/>
      <path d="M12 47 Q32 40 52 47" stroke="var(--pearl)" stroke-width="2.2" fill="none" stroke-linecap="round"/>
    </svg>`;
  const logo = () => (LOGO_SRC ? `<img class="logo-mark" src="${LOGO_SRC}" alt="">` : LOGO_SVG);

  const NAV = [
    { href: "about.html", label: "About" },
    { href: "schools.html", label: "Schools" },
    { href: "sponsors.html", label: "Sponsors" },
    { href: "contact.html", label: "Contact" },
  ];
  const page = (location.pathname.split("/").pop() || "index.html").toLowerCase();

  function renderHeader() {
    const host = $("[data-site-header]");
    if (!host) return;
    host.outerHTML = `
      <a class="skip-link" href="#main">Skip to content</a>
      <header class="site-header">
        <div class="container site-header__inner">
          <a class="brand" href="index.html" aria-label="${esc(S.name)} home">${logo()}<span class="brand__name">${esc(S.name)}</span></a>
          <nav class="nav" aria-label="Main">
            ${NAV.map((n) => `<a href="${n.href}"${page === n.href ? ' aria-current="page"' : ""}>${n.label}</a>`).join("")}
          </nav>
          <div class="header-cta">
            <a class="btn btn--ghost btn--sm" href="sponsor-us.html"${page === "sponsor-us.html" ? ' aria-current="page"' : ""}>Sponsor Us</a>
            <a class="btn btn--accent btn--sm" href="register.html"${page === "register.html" ? ' aria-current="page"' : ""}>Register Your School</a>
          </div>
          <button class="menu-btn" type="button" aria-expanded="false" aria-controls="mobile-menu" aria-label="Open menu"><span></span><span></span><span></span></button>
        </div>
        <div class="mobile-menu" id="mobile-menu" hidden>
          <a href="index.html">Home</a>
          ${NAV.map((n) => `<a href="${n.href}">${n.label}</a>`).join("")}
          <a href="sponsor-us.html">Sponsor Us</a>
          <a class="btn btn--accent" href="register.html">Register Your School</a>
        </div>
      </header>`;
  }

  function renderFooter() {
    const host = $("[data-site-footer]");
    if (!host) return;
    const socials = Object.entries(S.social || {}).filter(([, u]) => u)
      .map(([n, u]) => `<li><a href="${esc(u)}" target="_blank" rel="noopener">${n}</a></li>`).join("");
    host.outerHTML = `
      <footer class="site-footer">
        <svg class="ridge ridge--footer" viewBox="0 0 1440 90" preserveAspectRatio="none" aria-hidden="true"><path d="M0 90 L0 58 L120 30 L210 52 L330 14 L450 48 L560 26 L690 60 L800 22 L930 50 L1040 8 L1170 46 L1290 28 L1440 56 L1440 90 Z"/></svg>
        <div class="container site-footer__inner">
          <div class="site-footer__brand">
            <a class="brand" href="index.html">${logo()}<span class="brand__name">${esc(S.name)}</span></a>
            <p>${esc(S.fullName)}. Student-built bikes, judged and raced at the ${esc(S.venue)}.</p>
          </div>
          <div class="site-footer__cols">
            <ul><li><a href="about.html">About</a></li><li><a href="schools.html">Schools</a></li><li><a href="sponsors.html">Sponsors</a></li></ul>
            <ul><li><a href="register.html">Register Your School</a></li><li><a href="sponsor-us.html">Sponsor Us</a></li><li><a href="contact.html">Contact</a></li></ul>
            ${socials ? `<ul>${socials}</ul>` : ""}
          </div>
        </div>
        <div class="container site-footer__bottom">
          <span>© ${new Date().getFullYear()} ${esc(S.fullName)}</span>
          <a href="mailto:${esc(S.email)}">${esc(S.email)}</a>
        </div>
      </footer>`;
  }

  /* ---------- Content renderers ---------- */
  const schoolCard = (s) => {
    const inner = `
      <div class="school-card__photo">${s.photo
        ? `<img src="${esc(s.photo)}" alt="${esc(s.team && !/^TODO/.test(s.team) ? s.team : s.school)} team" loading="lazy">`
        : `<div class="ph">Team photo coming soon</div>`}</div>
      <div class="school-card__body">
        <div class="school-card__logo"><img src="${esc(s.logo)}" alt="${esc(s.school)}" loading="lazy"></div>
        <h3>${esc(s.school)}</h3>
        <p class="school-card__team">${txt(s.team)}</p>
        ${s.since ? `<p class="school-card__tag">${esc(s.since)}</p>` : ""}
        ${s.url ? `<span class="school-card__link">Visit team site <span aria-hidden="true">↗</span></span>` : ""}
      </div>`;
    return s.url
      ? `<a class="school-card" href="${esc(s.url)}" target="_blank" rel="noopener">${inner}</a>`
      : `<article class="school-card">${inner}</article>`;
  };

  const renderers = {
    schools: () => IBEC.schools.map(schoolCard).join(""),
    sponsors: () => IBEC.sponsors.map((s) => `
      <article class="sponsor-card">
        <a class="sponsor-card__logo" href="${esc(s.url)}" target="_blank" rel="noopener">${s.logo ? `<img src="${esc(s.logo)}" alt="${esc(s.name)}">` : `<span class="wordmark">${esc(s.name)}</span>`}</a>
        <div>
          <p class="eyebrow">${esc(s.role)}</p>
          <h3>${esc(s.name)}</h3>
          <p>${txt(s.blurb)}</p>
          <a class="text-link" href="${esc(s.url)}" target="_blank" rel="noopener">${esc(s.url.replace(/^https?:\/\/(www\.)?/, ""))} ↗</a>
        </div>
      </article>`).join(""),
    "sponsor-strip": () => IBEC.sponsors.map((s) => `
      <a class="strip-logo" href="${esc(s.url)}" target="_blank" rel="noopener">${s.logo ? `<img src="${esc(s.logo)}" alt="${esc(s.name)}">` : `<span class="wordmark">${esc(s.name)}</span>`}<small>${esc(s.role)}</small></a>`).join(""),
    faq: () => IBEC.faq.map((f) => `
      <details class="faq__item">
        <summary>${esc(f.q)}<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 9l6 6 6-6" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round"/></svg></summary>
        <div class="faq__answer"><p>${txt(f.a)}</p></div>
      </details>`).join(""),
    gallery: () => IBEC.gallery.map((g) => `<figure class="gallery__item"><img src="${esc(g.src)}" alt="${esc(g.alt)}" loading="lazy"></figure>`).join(""),
  };

  function renderAll() {
    $$("[data-render]").forEach((el) => {
      const fn = renderers[el.dataset.render];
      if (fn) el.innerHTML = fn();
    });
    $$("[data-email]").forEach((a) => { a.href = "mailto:" + S.email; if (!a.textContent.trim()) a.textContent = S.email; });
    $$("[data-site]").forEach((el) => { el.innerHTML = txt(S[el.dataset.site]); });
  }

  /* ---------- Header behaviour ---------- */
  function initHeader() {
    const header = $(".site-header");
    if (!header) return;
    const onScroll = () => header.classList.toggle("is-scrolled", window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    const btn = $(".menu-btn"), menu = $("#mobile-menu");
    btn?.addEventListener("click", () => {
      const open = btn.getAttribute("aria-expanded") !== "true";
      btn.setAttribute("aria-expanded", open);
      btn.setAttribute("aria-label", open ? "Close menu" : "Open menu");
      menu.hidden = !open;
      document.body.classList.toggle("menu-open", open);
    });
  }

  /* ---------- Marquee ribbon ---------- */
  function initRibbons() {
    $$("[data-ribbon]").forEach((el) => {
      const words = el.dataset.ribbon.split("•").map((w) => w.trim()).filter(Boolean);
      const run = words.map((w) => `<span>${esc(w)}</span><span class="dot" aria-hidden="true"></span>`).join("");
      el.setAttribute("aria-hidden", "true");
      el.innerHTML = `<div class="ribbon__track">${run.repeat(4)}${run.repeat(4)}</div>`;
    });
  }

  /* ---------- Forms → email (swap for a form service later) ---------- */
  function initForms() {
    $$("form[data-mailto]").forEach((form) => {
      form.addEventListener("submit", (e) => {
        e.preventDefault();
        if (!form.reportValidity()) return;
        const data = new FormData(form);
        const subject = form.dataset.mailto === "register"
          ? `IBEC registration: ${data.get("school") || ""}`
          : `IBEC: ${data.get("subject") || "Website message"}`;
        const body = Array.from(form.querySelectorAll("[name]"))
          .map((f) => `${f.dataset.label || f.name}: ${data.get(f.name) || ""}`).join("\n");
        location.href = `mailto:${S.email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
        const note = $(".form__note", form);
        if (note) note.textContent = "Your email app should open with the message filled in. If it doesn't, email us at " + S.email + ".";
      });
    });
  }

  /* ---------- Scroll reveal ---------- */
  function initReveal() {
    const els = $$(".reveal");
    if (!("IntersectionObserver" in window) || reduceMotion) return els.forEach((e) => e.classList.add("is-visible"));
    const io = new IntersectionObserver((entries) => entries.forEach((e) => {
      if (e.isIntersecting) { e.target.classList.add("is-visible"); io.unobserve(e.target); }
    }), { rootMargin: "0px 0px -8% 0px", threshold: 0.08 });
    els.forEach((e) => io.observe(e));
  }

  renderHeader();
  renderFooter();
  renderAll();
  initHeader();
  initRibbons();
  initForms();
  initReveal();
})();
