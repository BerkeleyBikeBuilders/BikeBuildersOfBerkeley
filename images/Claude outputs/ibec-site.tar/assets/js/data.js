/* =========================================================================
   IBEC site content. Edit this file to update the site; no build step.
   Text starting with "TODO:" shows up highlighted on the page so it's easy
   to spot what still needs real information.
   ========================================================================= */
window.IBEC = window.IBEC || {};
const IBEC = window.IBEC;

IBEC.site = {
  name: "IBEC",
  fullName: "Intercollegiate Bike Engineering Competition",
  // Contact + registration forms open the visitor's email app addressed here.
  email: "contact@bikebuilders.berkeley.edu", // TODO: switch to an IBEC address once the domain is set up
  venue: "Sea Otter Classic",
  venueUrl: "https://www.seaotterclassic.com",
  location: "Laguna Seca Recreation Area, Monterey, California",
  nextEvent: "TODO: Sea Otter Classic 2027 dates",
  // Social links in the footer (leave one out or empty to hide it).
  social: {
    Instagram: "", // TODO
  },
};

/* ---------- Participating schools (Schools page + home page) ----------
   photo:  team photo shown at the top of the card ("" = placeholder)
   logo:   university logo
   url:    team website (the whole card links there; "" = no link yet) */
IBEC.schools = [
  {
    school: "UC Berkeley",
    team: "Bike Builders of Berkeley",
    photo: "assets/img/team-berkeley.jpg",
    logo: "assets/img/schools/berkeley.svg",
    url: "https://bikebuilders.studentorg.berkeley.edu",
    since: "Founding team",
  },
  {
    school: "UC Santa Cruz",
    team: "TODO: team name",
    photo: "",
    logo: "assets/img/schools/ucsc.svg",
    url: "",
  },
];

/* ---------- Sponsors / partners ---------- */
IBEC.sponsors = [
  {
    name: "Sea Otter Classic",
    role: "Venue Partner",
    logo: "", // TODO: Sea Otter Classic logo file
    url: "https://www.seaotterclassic.com",
    blurb: "Sea Otter Classic donates the space where IBEC teams set up, show their bikes and compete, right in the middle of North America's biggest celebration of cycling.",
  },
];

/* ---------- FAQ (About page) ---------- */
IBEC.faq = [
  { q: "Who can compete?", a: "Any team of college or university students that designs and builds its own bicycle. Teams don't need to be a formal engineering club to take part." },
  { q: "Where is the competition held?", a: "At the Sea Otter Classic at Laguna Seca in Monterey, California, every spring." },
  { q: "Does the bike have to be built from scratch?", a: "TODO: describe what counts as a team-built bike (frame, components, off-the-shelf parts allowed)." },
  { q: "How are bikes judged?", a: "TODO: judging categories and criteria." },
  { q: "Is there an entry fee?", a: "TODO: entry fee, if any." },
  { q: "How do we sign up?", a: "Fill out the Register Your School form and we'll follow up with next steps." },
];

/* ---------- Gallery (About page) ---------- */
IBEC.gallery = [
  { src: "assets/img/bike-showcase.jpg",   alt: "A student-built full-suspension bike on display at Sea Otter" },
  { src: "assets/img/judging.jpg",         alt: "Visitors and media looking over a student-built bike" },
  { src: "assets/img/dirt-jump.jpg",       alt: "The dirt jump line in the hills at Laguna Seca" },
  { src: "assets/img/student-bike.jpg",    alt: "A student standing with the bike his team built" },
  { src: "assets/img/pit-work.jpg",        alt: "Students working on their bike in the pit area" },
  { src: "assets/img/hills-crowd.jpg",     alt: "Spectators on the hillside above the Sea Otter venue" },
  { src: "assets/img/steel-bike.jpg",      alt: "A student-built steel mountain bike" },
  { src: "assets/img/trials.jpg",          alt: "A trials rider hopping a feature at Sea Otter" },
  { src: "assets/img/team-2023.jpg",       alt: "Students with their bikes at Sea Otter 2023" },
  { src: "assets/img/venue-arch.jpg",      alt: "The Continental arch over the Laguna Seca track" },
];
